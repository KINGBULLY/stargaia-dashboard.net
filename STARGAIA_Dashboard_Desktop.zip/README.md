# STARGAIA Dashboard (Desktop Version)

This interface serves as the central access point for the STARGAIA ecosystem.
Access and deployment are available via GitHub Pages, IPFS gateways, or local preview.

## Files:
- `index.html`: Main dashboard UI
- `styles.css`: Visual theming
- `script.js`: Core logic
- `favicon.ico`: Icon placeholder
